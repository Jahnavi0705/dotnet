﻿namespace case_study_2.Controllers
{
    public class EcommerceDbContext
    {
    }
}