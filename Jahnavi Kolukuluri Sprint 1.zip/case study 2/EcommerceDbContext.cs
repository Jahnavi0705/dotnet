﻿namespace case_study_2
{
    internal class EcommerceDbContext
    {
    }
}